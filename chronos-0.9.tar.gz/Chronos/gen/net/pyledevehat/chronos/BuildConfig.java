/** Automatically generated file. DO NOT MODIFY */
package net.pyledevehat.chronos;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}